/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.little_bag;

/**
 *
 * @author DELL
 */
public class bag {
     String bid;
    String bname;
    String btype;
    String bsize;
    String bprice;
    String bstock;

    public bag(String bid, String bname, String btype, String bsize, String bprice, String bstock) {
        this.bid = bid;
        this.bname = bname;
        this.btype = btype;
        this.bsize = bsize;
        this.bprice = bprice;
        this.bstock = bstock;
    }
    
    public bag(){
        
    }

    public String getBid() {
        return bid;
    }

    public void setBid(String bid) {
        this.bid = bid;
    }

    public String getBname() {
        return bname;
    }

    public void setBname(String bname) {
        this.bname = bname;
    }

    public String getBtype() {
        return btype;
    }

    public void setBtype(String btype) {
        this.btype = btype;
    }

    public String getBsize() {
        return bsize;
    }

    public void setBsize(String bsize) {
        this.bsize = bsize;
    }

    public String getBprice() {
        return bprice;
    }

    public void setBprice(String bprice) {
        this.bprice = bprice;
    }

    public String getBstock() {
        return bstock;
    }

    public void setBstock(String bstock) {
        this.bstock = bstock;
    }
    
    
}
