/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.little_bag;

/**
 *
 * @author DELL
 */
public class Little_Bag {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
