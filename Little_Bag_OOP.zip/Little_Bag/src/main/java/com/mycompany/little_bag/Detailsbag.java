/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.little_bag;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author DELL
 */
public class Detailsbag {
        private static final String FILEPATH = "D:\\java\\Little_Bag\\src\\main\\java\\com\\mycompany\\little_bag\\Dbag.txt";
    
    FileWriter fw = null;
    BufferedWriter bw = null;
    
    public boolean addBagToTextFile(bag Bag){
        
        try {
            PrintWriter out = null;
            
            String bagdata = Bag.getBid() + "," + Bag.getBname() + "," + Bag.getBtype() + "," + Bag.getBsize() + "," + Bag.getBprice() + "," + Bag.getBstock();
            
            out = new PrintWriter(new BufferedWriter(new FileWriter(FILEPATH,true)));
            out.println(bagdata);
            
            out.close();
            
            JOptionPane.showMessageDialog(null, "Details are added");
            
        } catch (IOException ex) {
            Logger.getLogger(Detailsbag.class.getName()).log(Level.SEVERE, null, ex);
        }
       return true;
    }
    
    public bag findBagFromTexFile(String bagid) throws IOException{
        
       bag Bag = null;
        try {
            
            FileInputStream fileInputStream = new FileInputStream(FILEPATH);
            
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(fileInputStream));
            String readLine;
            
            while((readLine = bufferedReader.readLine())!=null){
                String[] detailsbag = readLine.split(",");
                if(bagid.equals(detailsbag[0])){
                    Bag = new bag();
                    Bag.setBid(detailsbag[0]);
                    Bag.setBname(detailsbag[1]);
                    Bag.setBtype(detailsbag[2]);
                    Bag.setBsize(detailsbag[3]);
                    Bag.setBprice(detailsbag[4]);
                    Bag.setBstock(detailsbag[5]);
                    
                    
                    
                }
            }
            
            
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Detailsbag.class.getName()).log(Level.SEVERE, null, ex);
     
        }
        
       return Bag;
    }
}
